class LocusIn :
    def __init__(self, marqueurCode, valAllele1, valAllele2):
        self.marqueurCode = marqueurCode
        self.valAllele1 = valAllele1
        self.valAllele1 = valAllele1

